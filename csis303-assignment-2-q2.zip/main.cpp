//Lukas Hunter
//CSIS 303 Assignment 2, Question 2
#include <vector>
#include <iostream>

using namespace std;

int main()
{
    //Stack declaration
    vector<int> vector1;
    
    //Checking if empty
    cout << "Empty: " << vector1.empty() << "\n";
    
    //Add some values
    vector1.push_back(4);
    vector1.push_back(8);
    vector1.push_back(12);
    vector1.push_back(16);
    
    //Remove the top value
    vector1.pop_back();
    
    //Print the top value
    cout << "Last element: " << vector1.back() << "\n";
    
    //Add all the values of the items in the stack
    int sum = 0;
    for (int i = 0; i < vector1.size(); i++)
    {
        sum += vector1.at(i);
    }
    
    //Print the average
    cout << "Average of the stack: " << sum / vector1.size();
    
    return 0;
}