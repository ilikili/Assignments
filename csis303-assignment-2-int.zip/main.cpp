#include <iostream>

using namespace std;

int ARRAYSIZE = 25;
int LASTELEMENTPOS = 0;
int HEAD = 0;
int TAIL = 0;

void push_front(int*& a_1, int iToAdd)
{
    if (ARRAYSIZE == LASTELEMENTPOS+1)
    {
        int* temp_a = new int[ARRAYSIZE*2];
        for (int i = 0; i < ARRAYSIZE; i++)
        {
            temp_a[i] = a_1[i];
        }
        
        delete[] a_1;
        
        a_1 = temp_a;
        ARRAYSIZE *= 2;
    }
    
    for (int i = ARRAYSIZE-1; i > 0; i--)
    {
        if (i != 0)
        {
            a_1[i] = a_1[i-1];
        }
    }
    a_1[0] = iToAdd;
    HEAD = a_1[0];
    LASTELEMENTPOS += 1;
    TAIL = a_1[LASTELEMENTPOS];
}

void push_back(int*& a_1, int iToAdd)
{
    if (ARRAYSIZE == LASTELEMENTPOS+1)
    {
        int* temp_a = new int[ARRAYSIZE*2];
        for (int i = 0; i < ARRAYSIZE; i++)
        {
            temp_a[i] = a_1[i];
        }
        
        delete[] a_1;
        
        a_1 = temp_a;
        ARRAYSIZE *= 2;
    }
    
    a_1[LASTELEMENTPOS+1] = iToAdd;
    LASTELEMENTPOS += 1;
    TAIL = a_1[LASTELEMENTPOS];
}



void pop_front(int*& a_1)
{
    
    for (int i = 0; i < ARRAYSIZE-1; i++)
    {
        if (i+1 != LASTELEMENTPOS+1)
        {
            a_1[i] = a_1[i+1];
        }
    }
    LASTELEMENTPOS -= 1;
    HEAD = a_1[0];
    TAIL = a_1[LASTELEMENTPOS];
}

void pop_back(int*& a_1)
{
    //Change the first value to 0
    a_1[LASTELEMENTPOS] = 0;
    //Decrease the recorded position of the last element by 1
    LASTELEMENTPOS -= 1;
}

int front(int*& a_1)
{
    //Since empty spots in the array are 0's (and the array only grows) 
    // there's no need for to check if the array is empty
    return a_1[0];
}

int back(int*& a_1)
{
    //Since the LASTELEMENTPOS will always be a number, 
    // there's no need for to check if the array is empty
    return a_1[LASTELEMENTPOS];
}



bool empty(int*& a_1)
{
    if (LASTELEMENTPOS == 0)
    {
        return true;
    } else { return false; }
}

void insert(int ARRAYSZ, int*& a_1, int insertPos, int iToAdd)
{
    if (ARRAYSIZE == LASTELEMENTPOS+1)
    {
        int* temp_a = new int[ARRAYSIZE*2];
        for (int i = 0; i < ARRAYSIZE; i++)
        {
            temp_a[i] = a_1[i];
        }
        
        delete[] a_1;
        
        a_1 = temp_a;
        ARRAYSIZE *= 2;
    }
    
    if (insertPos <= LASTELEMENTPOS)
    {
        for (int i = LASTELEMENTPOS+1; i >= insertPos; i--)
        {
            if (i-1 != -1)
            {
                a_1[i] = a_1[i-1];
            } else
            {
                a_1[0] = 0;
            }
        }
        a_1[insertPos] = iToAdd;
    }
    else
    {
        a_1[LASTELEMENTPOS+1] = iToAdd;
    }
    LASTELEMENTPOS += 1;
    HEAD = a_1[0];
    TAIL = a_1[LASTELEMENTPOS];
}

bool bool_remove(int*& a_1, int iToRemove)
{
    if (iToRemove < ARRAYSIZE+1)
    {
        for (int i = iToRemove; i < LASTELEMENTPOS; i++)
        {
            a_1[i] = a_1[i+1];
        }
        LASTELEMENTPOS -= 1;
        return true;
    }
    else
        return false;
    HEAD = a_1[0];
    TAIL = a_1[LASTELEMENTPOS];
}

int size_tfind(int*& a_1, int iToFind)
{
    //Loop through the array until it finds the value
    for (int i = 0; i < LASTELEMENTPOS; i++)
    {
        if (a_1[i] == iToFind)
            return i;
    }
    
    //If it didn't return while in the loop, return the size of the array
    return ARRAYSIZE;
}

void print(int*& a_1)
{
    cout << "\n";
    for (int i = 0; i < LASTELEMENTPOS; i++)
    {
        cout << i << ": " << a_1[i] << "\n";
    }
}

int main()
{
    
    int* dynamicArray = new int[25];
    
    for (int i = 0; i < ARRAYSIZE; i++)
    {
        dynamicArray[i] = 0;
    }
    
    LASTELEMENTPOS = 24;
    
    //int choice is the selection of the user
    //int chosenNum will be input from the user, for values to be used
    int choice = -1;
    int chosenNum = 0;
    int chosenNum2 = 0;
    while  (choice != 0)
    {
        cout << "Choose a function:" << endl;
        cout << "0: Exit" << endl;
        cout << "1: push_front" << endl;
        cout << "2: push_back" << endl;
        cout << "3: pop_front" << endl;
        cout << "4: pop_back" << endl;
        cout << "5: front" << endl;
        cout << "6: back" << endl;
        cout << "7: empty" << endl;
        cout << "8: insert" << endl;
        cout << "9: bool_remove" << endl;
        cout << "10: size_tfind" << endl;
        cout << "11: print" << endl;
        cin >> choice;
        
        switch (choice)
        {
            case 1:
                cout << "Choose a value to push: ";
                cin >> chosenNum; cout << endl;
                push_front(dynamicArray,chosenNum);
                break;
            case 2:
                cout << "Choose a value to push to the back: ";
                cin >> chosenNum; cout << endl;
                push_back(dynamicArray,chosenNum);
                break;
            case 3:
                pop_front(dynamicArray);
                break;
            case 4:
                pop_back(dynamicArray);
                break;
            case 5:
                cout << "Front value: " << front(dynamicArray) << "\n";
                break;
            case 6:
                cout << "Front value: " << back(dynamicArray) << "\n";
                break;
            case 7: 
                cout << "Is empty: " << empty << "\n";
                break;
            case 8:
                cout << "Choose a value to insert: ";
                cin  >> chosenNum;
                cout << "\n";
                cout << "Choose the position to insert it: ";
                cin >> chosenNum2;
                cout << "\n";
                insert(ARRAYSIZE,dynamicArray,chosenNum2,chosenNum);
                break;
            case 9:
                cout << "Choose the position to remove: ";
                cin >> chosenNum;
                cout << "\n";
                bool_remove(dynamicArray,chosenNum);
                break;
            case 10:
                cout << "Choose the value of the number to find: ";
                cin >> chosenNum;
                cout << "\n";
                cout << "Output: " << size_tfind(dynamicArray,chosenNum) << "\n";
                break;
            case 11:
                print(dynamicArray);
                break;
                
        }
    
    

    }
    
    return 0;
}

